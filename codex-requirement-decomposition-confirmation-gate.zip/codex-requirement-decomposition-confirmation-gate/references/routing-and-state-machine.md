# 门禁路由、状态机与结构协议

## 目录

1. [路由输入](#路由输入)
2. [判级规则](#判级规则)
3. [授权与确认语义](#授权与确认语义)
4. [状态转移](#状态转移)
5. [确认包字段](#确认包字段)
6. [任务树与追溯](#任务树与追溯)
7. [变更分类](#变更分类)
8. [最终状态](#最终状态)

## 路由输入

每个任务先建立临时 `gate_context`：

```yaml
request_clarity: clear | partial | vague
object_identity: confirmed | uncertain
scope_breadth: local | multi_file | cross_system
consequence: low | medium | high
reversibility: easy | difficult | irreversible
external_side_effects: none | bounded | production_or_public
sensitive_domain: none | research | clinical | legal | financial | security
required_evidence: obvious | testable | expert_judgment
user_authorization: explicit | partial | absent
material_unresolved_decisions: []
```

该对象用于判断，不要求始终展示。

## 判级规则

### G0 必须同时满足

- 无 MUD；
- 对象身份已确认；
- 修改范围局部；
- 低后果且易回滚；
- 无生产、公开、密钥、权限或敏感领域影响；
- 验收可直接观察；
- 用户已经明确请求该动作。

### G1 适用条件

- 存在轻微缺省，但有公认、低风险、易回滚的默认值；
- 默认值不改变公共接口、数据或用户主要目标；
- 执行前能够一句话声明默认值；
- 一旦默认值失效，可以在扩大影响前停止。

G1 不是“模型觉得问题不大”。必须写出默认值及其影响。

### G2 触发条件

任一项成立：

- 有 MUD；
- 两种合理解释会生成不同类型的产物；
- 跨多个子系统，错误方向会产生大量返工；
- 需要选择数据、方法、架构或兼容策略；
- 成功标准不明确；
- 需要新增依赖、网络或外部服务，但不属于立即高影响动作；
- 用户目标与现状明显不一致；
- 需要修改用户声明要保留的边界。

### G3 触发条件

任一项成立：

- 删除、覆盖、迁移或不可恢复修改；
- 生产数据库、部署、公开发布或自动合并；
- 真实密钥、权限提升或外部代码执行；
- 大额成本、不可撤销采购或外部通知；
- 自动生成或执行可能影响科研、临床、法律、财务、安全决策的结论；
- 回滚方案不确定或未验证；
- 影响对象数量或边界无法准确列举。

## 授权与确认语义

### 原始请求可直接提供授权

下列条件同时满足时，不要求重复确认：

- 用户明确使用动作动词请求实施；
- 目标对象和边界明确；
- 无 MUD；
- 门禁等级为 G0 或 G1；
- 更高优先级策略未要求额外审批。

### 明确确认的最小要求

G2/G3 的确认应能映射到当前规格版本：

```text
确认执行
确认 SPEC-20260624-01 v2
D-01=A，D-02=保持兼容，然后执行
只确认并执行阶段 1
```

### 不能视为确认

```text
看着办
应该可以
继续说
沉默
只回答了 D-01
此前确认过相似任务
```

“看着办”可以授权低风险实现细节，但不能覆盖高影响动作或未决范围。

### 部分确认

将每个决策标记为：

```yaml
status: OPEN | CONFIRMED | REJECTED | SUPERSEDED
```

只有所有 blocking 决策都已解决，相关执行才允许开始。

## 状态转移

| 当前状态 | 事件 | 下一状态 | 允许动作 |
|---|---|---|---|
| RECEIVED | 完成判级 | TRIAGED | 读取、路由 |
| TRIAGED | 需要事实 | READ_ONLY_AUDIT | 只读检查 |
| TRIAGED | 不需要事实 | SPEC_DRAFTED | 写规格 |
| READ_ONLY_AUDIT | 事实足够 | SPEC_DRAFTED | 写规格 |
| SPEC_DRAFTED | G0 | EXECUTING | 按明确请求执行 |
| SPEC_DRAFTED | G1 | DEFAULTS_DECLARED | 声明默认值 |
| DEFAULTS_DECLARED | 默认值仍安全 | EXECUTING | 执行 |
| SPEC_DRAFTED | G2/G3 | NEEDS_CONFIRMATION | 输出确认包 |
| NEEDS_CONFIRMATION | blocking 决策全部确认 | CONFIRMED | 冻结基线 |
| CONFIRMED | 建立基线 | EXECUTING | 分批实施 |
| EXECUTING | 发生实质变化 | RECONFIRM_REQUIRED | 停止受影响部分 |
| EXECUTING | 到达 G3 动作点 | STOPPED_FOR_SAFETY | point-of-action time-out |
| EXECUTING | 批次完成 | VERIFYING | 测试与审查 |
| VERIFYING | 证据足够 | ACCEPTANCE_REVIEW | 语义验收 |
| ACCEPTANCE_REVIEW | 全部满足 | COMPLETED | 最终报告 |
| ACCEPTANCE_REVIEW | 部分满足 | PARTIAL | 列出未完成 |
| ACCEPTANCE_REVIEW | 关键失败 | FAILED | 失败与恢复报告 |

### 状态不变量

- `NEEDS_CONFIRMATION`：不得实施被门禁的写操作。
- `STOPPED_FOR_SAFETY`：不得执行具体高影响动作。
- `EXECUTING`：每个动作必须映射至少一个 T-xx 与 R-xx。
- `COMPLETED`：每个主要 R-xx 必须有通过的 AC-xx 证据。

## 确认包字段

确认包按用户可审阅顺序组织：

1. 原始请求；
2. 最终可观察结果；
3. 交付物；
4. 范围、非目标、保留和禁止事项；
5. 已确认事实；
6. 假设与建议默认值；
7. 任务阶段与方法；
8. 验收标准；
9. 关键风险和停止条件；
10. blocking 决策及回复方式。

不要把全部内部任务细节都放进用户确认包。叶子任务可保留在结构化规格中，用户界面只展示能发现理解偏差的层级。

## 任务树与追溯

### 叶子任务要求

一个叶子任务应满足：

- 有单一目的；
- 输入和输出可列举；
- 能在一个验证边界内完成；
- 失败不会迫使整个任务不可恢复；
- 明确哪些需求被覆盖；
- 不使用“全面、全部、彻底”等无边界描述。

### 追溯矩阵

```text
R-xx -> T-xx -> 方法/命令 -> 输出 -> AC-xx -> 证据
```

检查：

- 每个 R-xx 是否至少映射一个 T-xx；
- 每个主要 T-xx 是否服务某个 R-xx；
- 每个 R-xx 是否至少有一个 AC-xx；
- 是否存在“孤儿任务”或“孤儿验收项”；
- 禁止事项是否有对应负向验证。

## 变更分类

### C0 非实质变化

示例：局部变量名、内部函数拆分、测试夹具调整，不改变接口、数据、风险或验收。

处理：记录后继续。

### C1 实质变化

示例：新增主要交付物、更换架构、改变数据来源、调整兼容边界、扩大文件范围。

处理：

1. 停止受影响部分；
2. 说明触发事实；
3. 给出旧方案与新方案差异；
4. 更新规格版本；
5. 请求确认。

### C2 高影响变化

示例：需要生产凭据、删除真实数据、公开发布、自动合并、不可逆迁移。

处理：升级 G3，并在动作点再次确认。

## 最终状态

### COMPLETED

只有以下全部成立：

- 所有确认的主要需求均满足；
- 所有关键验收通过；
- 偏离均已披露并获确认；
- 无未处理的高风险副作用；
- 回滚或恢复信息可用。

### PARTIAL

部分需求满足，但存在明确未完成项。必须列出：

- 已完成范围；
- 未完成范围；
- 原因；
- 影响；
- 继续所需条件。

### FAILED

关键目标未达到，或执行造成不可接受偏离。必须列出：

- 失败证据；
- 已采取恢复动作；
- 当前系统状态；
- 不应继续的原因。
