#!/usr/bin/env python3
"""Validate a request-spec JSON produced by the confirmation-gate skill.

Uses only the Python standard library. It checks structural completeness,
identifier uniqueness, traceability, and confirmation/gate consistency.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Iterable

ALLOWED_GATES = {"G0", "G1", "G2", "G3"}
ALLOWED_SPEC_STATUS = {
    "DRAFT",
    "NEEDS_CONFIRMATION",
    "CONFIRMED",
    "EXECUTING",
    "VERIFYING",
    "COMPLETED",
    "PARTIAL",
    "FAILED",
    "BLOCKED",
    "RECONFIRM_REQUIRED",
    "STOPPED_FOR_SAFETY",
}
ALLOWED_CONFIRMATION_STATUS = {
    "NOT_REQUIRED",
    "NEEDS_CONFIRMATION",
    "PARTIALLY_CONFIRMED",
    "CONFIRMED",
    "REJECTED",
    "SUPERSEDED",
}
REQUIRED_TOP_LEVEL = {
    "spec_id",
    "spec_version",
    "status",
    "gate_class",
    "original_request",
    "authorization",
    "desired_outcome",
    "deliverables",
    "requirements",
    "in_scope",
    "out_of_scope",
    "preserve",
    "forbidden",
    "known_facts",
    "assumptions",
    "proposed_defaults",
    "decisions_required",
    "task_tree",
    "acceptance_criteria",
    "risks",
    "stop_conditions",
    "change_control",
    "confirmation",
}
PLACEHOLDER_MARKERS = ("<", ">", "YYYYMMDD", "TODO", "TBD")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Validate a confirmation-gate request-spec JSON file."
    )
    parser.add_argument("path", type=Path, help="Path to request-spec JSON")
    parser.add_argument(
        "--strict",
        action="store_true",
        help="Also reject blank required content and obvious template placeholders.",
    )
    return parser.parse_args()


def load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ValueError(f"file not found: {path}") from exc
    except UnicodeDecodeError as exc:
        raise ValueError(f"file is not valid UTF-8: {path}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(
            f"invalid JSON at line {exc.lineno}, column {exc.colno}: {exc.msg}"
        ) from exc


def ensure_type(errors: list[str], value: Any, expected: type, label: str) -> bool:
    if not isinstance(value, expected):
        errors.append(f"{label} must be {expected.__name__}")
        return False
    return True


def collect_ids(
    errors: list[str], items: Any, label: str, prefix: str | None = None
) -> set[str]:
    ids: set[str] = set()
    if not ensure_type(errors, items, list, label):
        return ids
    for index, item in enumerate(items):
        item_label = f"{label}[{index}]"
        if not isinstance(item, dict):
            errors.append(f"{item_label} must be object")
            continue
        value = item.get("id")
        if not isinstance(value, str) or not value.strip():
            errors.append(f"{item_label}.id must be non-empty string")
            continue
        if value in ids:
            errors.append(f"duplicate id in {label}: {value}")
        ids.add(value)
        if prefix and not value.startswith(prefix):
            errors.append(f"{item_label}.id should start with {prefix}: {value}")
    return ids


def references_exist(
    errors: list[str], refs: Iterable[Any], valid: set[str], label: str
) -> None:
    for ref in refs:
        if not isinstance(ref, str):
            errors.append(f"{label} contains non-string reference: {ref!r}")
        elif ref not in valid:
            errors.append(f"{label} references missing id: {ref}")


def contains_placeholder(value: str) -> bool:
    upper = value.upper()
    return any(marker.upper() in upper for marker in PLACEHOLDER_MARKERS)


def validate(data: Any, strict: bool) -> list[str]:
    errors: list[str] = []
    if not isinstance(data, dict):
        return ["top-level JSON value must be an object"]

    missing = sorted(REQUIRED_TOP_LEVEL - data.keys())
    if missing:
        errors.append("missing top-level keys: " + ", ".join(missing))

    gate = data.get("gate_class")
    if gate not in ALLOWED_GATES:
        errors.append(f"gate_class must be one of {sorted(ALLOWED_GATES)}")

    status = data.get("status")
    if status not in ALLOWED_SPEC_STATUS:
        errors.append(f"status must be one of {sorted(ALLOWED_SPEC_STATUS)}")

    if not isinstance(data.get("spec_version"), int) or data.get("spec_version", 0) < 1:
        errors.append("spec_version must be integer >= 1")

    for key in (
        "deliverables",
        "in_scope",
        "out_of_scope",
        "preserve",
        "forbidden",
        "known_facts",
        "assumptions",
        "proposed_defaults",
        "decisions_required",
        "task_tree",
        "acceptance_criteria",
        "risks",
        "stop_conditions",
    ):
        if key in data:
            ensure_type(errors, data[key], list, key)

    requirement_ids = collect_ids(errors, data.get("requirements"), "requirements", "R-")
    task_ids = collect_ids(errors, data.get("task_tree"), "task_tree", "T-")
    acceptance_ids = collect_ids(
        errors, data.get("acceptance_criteria"), "acceptance_criteria", "AC-"
    )
    collect_ids(errors, data.get("known_facts"), "known_facts", "F-")
    collect_ids(errors, data.get("assumptions"), "assumptions", "A-")
    collect_ids(
        errors, data.get("proposed_defaults"), "proposed_defaults", "PD-"
    )
    collect_ids(
        errors, data.get("decisions_required"), "decisions_required", "D-"
    )
    collect_ids(errors, data.get("risks"), "risks", "HZ-")

    for index, req in enumerate(data.get("requirements", [])):
        if not isinstance(req, dict):
            continue
        refs = req.get("acceptance_ids", [])
        if not isinstance(refs, list):
            errors.append(f"requirements[{index}].acceptance_ids must be list")
        else:
            if not refs:
                errors.append(f"requirements[{index}] has no acceptance_ids")
            references_exist(
                errors, refs, acceptance_ids, f"requirements[{index}].acceptance_ids"
            )

    covered_requirements: set[str] = set()
    for index, task in enumerate(data.get("task_tree", [])):
        if not isinstance(task, dict):
            continue
        req_refs = task.get("requirement_ids", [])
        if not isinstance(req_refs, list):
            errors.append(f"task_tree[{index}].requirement_ids must be list")
        else:
            references_exist(
                errors, req_refs, requirement_ids, f"task_tree[{index}].requirement_ids"
            )
            covered_requirements.update(ref for ref in req_refs if isinstance(ref, str))
        ac_refs = task.get("validation", [])
        if not isinstance(ac_refs, list):
            errors.append(f"task_tree[{index}].validation must be list")
        else:
            references_exist(
                errors, ac_refs, acceptance_ids, f"task_tree[{index}].validation"
            )

    for requirement_id in sorted(requirement_ids - covered_requirements):
        errors.append(f"requirement has no task coverage: {requirement_id}")

    confirmation = data.get("confirmation")
    if not isinstance(confirmation, dict):
        errors.append("confirmation must be object")
    else:
        confirmation_status = confirmation.get("status")
        if confirmation_status not in ALLOWED_CONFIRMATION_STATUS:
            errors.append(
                "confirmation.status must be one of "
                + str(sorted(ALLOWED_CONFIRMATION_STATUS))
            )
        execution_allowed = confirmation.get("execution_allowed")
        if not isinstance(execution_allowed, bool):
            errors.append("confirmation.execution_allowed must be boolean")
        if gate in {"G2", "G3"} and execution_allowed:
            if confirmation_status != "CONFIRMED":
                errors.append(
                    f"{gate} cannot allow execution unless confirmation.status is CONFIRMED"
                )
            if not confirmation.get("confirmed_by"):
                errors.append("confirmed_by is required when execution is allowed")
            if not confirmation.get("confirmed_at"):
                errors.append("confirmed_at is required when execution is allowed")

    change_control = data.get("change_control")
    if not isinstance(change_control, dict):
        errors.append("change_control must be object")
    elif gate == "G3" and change_control.get(
        "point_of_action_confirmation_required"
    ) is not True:
        errors.append(
            "G3 requires change_control.point_of_action_confirmation_required=true"
        )

    if strict:
        for key in ("spec_id", "original_request", "desired_outcome"):
            value = data.get(key)
            if not isinstance(value, str) or not value.strip():
                errors.append(f"{key} must be non-empty in strict mode")
            elif contains_placeholder(value):
                errors.append(f"{key} contains template placeholder in strict mode")
        for key in ("deliverables", "requirements", "task_tree", "acceptance_criteria"):
            value = data.get(key)
            if not isinstance(value, list) or not value:
                errors.append(f"{key} must be non-empty in strict mode")
        for collection_key, text_keys in {
            "requirements": ("statement",),
            "task_tree": ("purpose", "method", "method_rationale"),
            "acceptance_criteria": ("statement", "evidence", "rejection_condition"),
        }.items():
            for index, item in enumerate(data.get(collection_key, [])):
                if not isinstance(item, dict):
                    continue
                for text_key in text_keys:
                    value = item.get(text_key)
                    if not isinstance(value, str) or not value.strip():
                        errors.append(
                            f"{collection_key}[{index}].{text_key} must be non-empty in strict mode"
                        )
                    elif contains_placeholder(value):
                        errors.append(
                            f"{collection_key}[{index}].{text_key} contains placeholder"
                        )

    # Guard against a structurally empty file that happens to have valid IDs.
    if not task_ids:
        errors.append("task_tree must contain at least one task")
    if not requirement_ids:
        errors.append("requirements must contain at least one requirement")
    if not acceptance_ids:
        errors.append("acceptance_criteria must contain at least one criterion")

    return errors


def main() -> int:
    args = parse_args()
    try:
        data = load_json(args.path)
    except ValueError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    errors = validate(data, strict=args.strict)
    if errors:
        print(f"INVALID: {args.path}", file=sys.stderr)
        for error in errors:
            print(f"- {error}", file=sys.stderr)
        return 1

    print(f"VALID: {args.path}")
    print(
        json.dumps(
            {
                "spec_id": data.get("spec_id"),
                "gate_class": data.get("gate_class"),
                "status": data.get("status"),
                "requirements": len(data.get("requirements", [])),
                "tasks": len(data.get("task_tree", [])),
                "acceptance_criteria": len(data.get("acceptance_criteria", [])),
                "execution_allowed": data.get("confirmation", {}).get(
                    "execution_allowed"
                ),
            },
            ensure_ascii=False,
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
